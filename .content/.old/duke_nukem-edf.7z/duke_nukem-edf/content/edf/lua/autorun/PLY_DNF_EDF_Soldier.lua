 
-- Duke Nukem Forever EDF Soldier Player Model
-- Model @ Gearbox
-- Player @ V92
-- 20 October 2013

player_manager.AddValidModel("EDFSoldier", "models/jessev92/player/misc/edfsoldier.mdl" )
player_manager.AddValidHands( "EDFSoldier", "models/weapons/c_arms_combine.mdl", 0, "00000000" )
